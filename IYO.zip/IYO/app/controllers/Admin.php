<?php
class Admin extends \app\libs\Controller
{
    public function __construct()
    {

    }
    public function notification()
    {
        if($_SERVER['REQUEST_METHOD'] == "POST")
        {

        }
        else
        {
            $this->view("admin/notification");
        }
    }

}