<?php

class Event extends \app\libs\Controller
{
    public function __construct()
    {
        if(app\config\Configs::getUserSession("Current_User") == false &&
        \app\config\Configs::getUserSession("Current_Admin") == false)
        {
            \app\config\Configs::redirectPage(\app\config\Configs::$urlroot);
        }
        else
        {
            $this->eventmodel = $this->model("EventModel");
        }

    }

    public function index()
    {
        /*$data = [
            "event" => ''
        ];*/
        $data = $this->eventmodel->getAllPostsByCategoryId(1);

        $this->view("event/index",$data);
    }
    public function details($params = [])
    {
        $data = $this->eventmodel->getEventById($params[0]);
        $this->view("event/details",$data);
    }
    public function create()
    {

        $data = [
            "eventid" => '',
            "eventcount" =>'',
            "title" => '',
            "description" => '',
            "speaker" => '',
            "date" => '',
            "content" => '',
            "file" => '',

        ];
        $data['eventcount'] =  $this->eventmodel->getAllPostsByCategoryId(1);

        if($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $data['eventid'] = count($data['eventcount']) + 1;
            $data['title'] = htmlspecialchars($_POST['title'],ENT_QUOTES);
            $data['description'] = htmlspecialchars($_POST['desp'],ENT_QUOTES);
            $data['speaker'] = htmlspecialchars($_POST['speaker'],ENT_QUOTES);
            $data['date'] = htmlspecialchars($_POST['date'],ENT_QUOTES);
            $data['content'] = htmlspecialchars($_POST['content'],ENT_QUOTES);
            $data['file'] = $data['eventid']."__".$_FILES['file']['name'];
            $root = dirname(dirname(dirname(__FILE__)));
            if($this->eventmodel->insertEvent($data['title'],$data['description'],$data['speaker'],$data['date'],$data['content'],$data['file']))
            {
                move_uploaded_file($_FILES['file']['tmp_name'],$root."/public/assets/upload/".$data['file']);
                \app\config\Configs::redirectPage(\app\config\Configs::$urlroot."Event");
            }
            else
            {
                $this->view("event/create");
            }


        }
        else
        {
            $this->view("event/create");
        }
    }
    public function edit($params = [])
    {
        $data = [
            "event" => '',
            "title" => '',
            "description" => '',
            "speaker" => '',
            "date" => '',
            "content" => '',
            "file" => '',
        ];
        $data["event"] = $this->eventmodel->getEventById($params[0]);
        if($_SERVER["REQUEST_METHOD"] == "POST")
        {
            /* $_POST  =filter_input_array(INPUT_POST,FILTER_SANITIZE_STRING);*/
             $data['title'] = htmlspecialchars($_POST['title'],ENT_QUOTES);
             $data['description'] = htmlspecialchars($_POST['desp'],ENT_QUOTES);
             $data['speaker'] = htmlspecialchars($_POST['speaker'],ENT_QUOTES);
            $data['date'] = htmlspecialchars($_POST['date'],ENT_QUOTES);
             $data['content'] = htmlspecialchars($_POST['content'],ENT_QUOTES);
             $data['file'] = $data['event']->eventid."__".$_FILES['file']['name'];
             $root = dirname(dirname(dirname(__FILE__)));
             if($this->eventmodel->updateEvent($data['event']->eventid,$data['title'],$data['description'],$data['speaker'],$data['date'],$data['content'],$data['file']))
             {
                 if($data['file'] != $data['event']->image)
                 {
                     move_uploaded_file($_FILES['file']['tmp_name'],$root."/public/assets/upload/".$data['file']);


                 }

               \app\config\Configs::redirectPage(\app\config\Configs::$urlroot."Event");

             }
             else
             {

                 $this->view("event/edit",$data);
             }



        }
        else
        {

            $this->view("event/edit",$data);
        }

    }
    public function delete($params = [])
    {
        if($this->eventmodel->deleteEvent($params[0]))
        {
            \app\config\Configs::redirectPage(\app\config\Configs::$urlroot."Event");
        }
    }
    public function team()
    {
        $this->view("event/team");
    }
    public function notification($params = [])
    {
        if($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $data = [
                "event" => $params[0],
                "email" => $_POST["hidden"]
            ];
            if($this->eventmodel->getNotificationByUser($data['event'],$data['email']) > 0)
            {
                \app\config\Configs::redirectPage(\app\config\Configs::$urlroot."Event");
            }
            else
            {
                if($this->eventmodel->getNotification($data["event"],$data['email']))
                {
                    \app\config\Configs::redirectPage(\app\config\Configs::$urlroot."Event");
                }
                else
                {
                    \app\config\Configs::redirectPage(\app\config\Configs::$urlroot."Event");
                }
            }

        }
    }
}