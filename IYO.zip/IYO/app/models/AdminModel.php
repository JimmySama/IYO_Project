<?php
class AdminModel
{
    private $db;
    public function __construct()
    {
        $this->db = new \app\libs\Db();
    }
    public function getAdminByEmail($email)
    {
        $this->db->query("SELECT * FROM admin WHERE email = :email");
        $this->db->bind(":email",$email);
        return $this->db->singleSet();
    }
}